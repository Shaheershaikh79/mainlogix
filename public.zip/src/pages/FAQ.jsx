import React from 'react'
import { Link } from 'react-router-dom'
import SectionHeader from '../components/SectionHeader'
import styles from '../sass/pages/FAQ.module.scss'
import Accordion from '../components/Accordion'
import Projects from '../components/FAQ.jsx/Projects'
import Header from '../components/Header'
import faqIllustration from '../assets/images/faqIllustration.svg'
import Footer from '../components/Footer'

const FAQ = () => {

  const faqs = [
    {
      question: "How does Grandeur Smart Products Work?",
      answer: "Grandeur Smart products require an existing home wifi network for setup and Use and if you dont have existing wifi you can select a gateway with SIm card(Internet Access), also you will need a smart device (phone or tablet) and the Grandeur smart app, which allows you to control all the functions in your network."
    },
    {
      question: "How many devices are supported by Grandeur Smart Gateway?",
      answer: "All Grandeur smart devices are compatible with 2.4 GHz networks. Some Grandeur devices are able to use 5 GHz networks. Devices that can connect to Grandeursmart Gateway range from Lora smart devices, WiFi smart devices, Bluetooth Smart devices, Zigbee Smart devices, Zwaves smart devices and Matter smart devices."
    },
    {
      question: "Different Types of Mainlogix Products",
      answer: "Mainlogix has a variety of indoor and outdoor devices that are battery-powered, plug-in or hardwired."
    },
    {
      question: " Is there a warranty on Mainlogix products?",
      answer: "Yes. All Mainlogix devices come with a limited warranty and theft protection. You can get an extended warranty for all Mainlogix devices when you subscribe to Mainlogix Extended packages."
    },
    {
      question: "How do I track my order?",
      answer: "After you place your order, we'll send you an Order Confirmation to your email.In the shipping email we send you 2-3 days after your purchase, you can select Track Order or View Order to get details about your tracking information."
    },
    {
      question: "Can I cancel my Mainlogix order??",
      answer: "Yes. You can cancel your order up to 45 minutes after purchase. If you miss the cancellation window, you can start a return. How to cancel your order."
    },
    {
      question: "What version of iPhone, iPad, or Android do I need in order to use the Mainlogix app?",
      answer: "Apple devices must be on iOS 12.0 or newer, or iPadOS 12.0 or newer. Android devices must be version 6.0 or newer.Mainlogix products aren’t compatible with Blackberry devices."
    },
    {
      question: "Does Mainlogix support WPA2?",
      answer: "Yes. Mainlogix devices support WPA2, WPA, and 64-bit WEP Hex. We recommend WPA2 for best results."
    },
  ]

  return (
    <div className={styles.faq}>
      <Header />
      <div className={styles.hero}>
        <div className={styles.heroDesc}>
          <div className={styles.plusIcon}>
            +
          </div>
          <SectionHeader text="Frequently asked questions" fontSize="1.5rem" />
          <p>
          </p>
          <Link to="/contact">ASK A QUESTION</Link>
        </div>
        <div className={styles.heroIllustration}>
          <img src={faqIllustration} alt="question mark" />
        </div>
      </div>
      <div className={styles.faqList}>
        <h3>General Questions</h3>
        <Accordion faqs={faqs} />
      </div>
      <Projects />
      <Footer />
    </div>
  )
}

export default FAQ
