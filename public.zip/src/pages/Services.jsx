import React from 'react'
import Hero from '../components/Services/Hero'
import Service from '../components/Services/Service'
import TopServices from '../components/Services/TopServices'
import styles from '../sass/pages/Services.module.scss'
import Footer from '../components/Footer'

import agricultural from '../assets/images/agricultural.svg'
import education from '../assets/images/education.svg'
import finance from '../assets/images/finance.svg'
import hospitality from '../assets/images/hospitality.svg'
import industrial from '../assets/images/industrial.svg'
import medicine from '../assets/images/medicine.svg'
import transport from '../assets/images/transport.svg'
import iot from '../assets/images/iot.svg'

const Services = () => {

  const paragraph1 = "With Mainlogix Smart Agriculture solution, farm devices and implements will become easier to use and operate. The capability to measure real-time data enables farmers to maximize equipment performance, optimize labour, and increase the quantity and quality of products. It will change the face of agriculture from the hard labour narrative to intelligent and automated farming."
  const paragraph2 = "The idea of Smart Schools is still very novel. If education is getting decentralized, all learners should at one point in the future be able to control the type of instruction they get and how it is shared with them.With MainLogix Smart school devices, the education systems will transform and improve. This will improve students academically while also improving teaching efficiency with improved security for both learner and learning environment."
  const paragraph3 = "Smart Cities or Communities enhance governance at the grassroots level of society by helping to bring public administration to the control of the people themselves. And with MainLogix’ Smart Cities devices forming a better part of public infrastructure, people can expect optimized management of public resources in a smartly organized city/community."
  const paragraph4 = "In the health care sector, Mainlogix systems bring automation to solving myriads of problems medical professionals face when diagnosing diseases or conditions. These smart systems will enable devices to be more proactive by enabling enhanced connectivity to the bodies of patients in health diagnosis."
  const paragraph5 = "The Internet of Things enables industries and enterprises to provide efficient and reliable operations to diverse levels of the industrial value chain by optimizing its processes.Mainlogix IoT solutions introduce efficient robotic systems and devices for smooth production processes."
  const paragraph6 = "Smart elderly/Realtime patient care hardware solutions enable them to live independently at home for longer periods of time. It can detect the life trajectory of the elderly and can also protect the safety of the elderly. It is used to Monitor and also send Notification and also gives a preventive measure rather than Emergency situation."

  const paragraph7 = "Transportation is an essential part of human reality.Mainlogix IoT solution is streamlining logistics processes with Smart systems that can remotely control elements of the transportation process"
  const paragraph8 = "Mainlogix system devices can accommodate user preferences for convenience in their homes. Think of users being able to program their garage door to open as their vehicle approaches the home, or the lights going on as you enter a room. Even the fireplace could turn up the heat as a favorite tune plays over the speakers.All of these point to a wonderful immersion in a world of make-believe. There are a few things cooler than controlling your home from anywhere in the world."

  const services = [
    {
      img: agricultural,
      heading: "Smart Agriculture",
      summary: paragraph1
    },{
      img: education,
      heading: "Smart School",
      summary: paragraph2
    },{
      img: finance,
      heading: "Smart Cities / Communities",
      summary: paragraph3
    },{
      img: hospitality,
      heading: "Medical IoT",
      summary: paragraph4
    },{
      img: industrial,
      heading: "Industrial IoT",
      summary: paragraph5
    },{
      img: medicine,
      heading: "Smart Elderly/Realtime Patient care IOT",
      summary: paragraph6
    },{
      img: transport,
      heading: "Logistics IoT",
      summary: paragraph7
    },{
      img: iot,
      heading: "Smart Home",
      summary: paragraph8
    }
  ]
  return (
    <main className={styles.services}>
      <Hero />
      <div className={styles.serviceList}>
        {services.map(service => (
          <Service service={service} />
        ))}
      </div>
      {/* <TopServices /> */}
      <Footer />
    </main>
  )
}

export default Services
