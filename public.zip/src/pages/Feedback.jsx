import React, { useState } from 'react'
import styles from '../sass/pages/Feedback.module.scss'
import logo from '../assets/images/Logo.png'
import { Link } from 'react-router-dom'
import Header from '../components/Header'
import Star from '../assets/icons/Star'

const Feedback = () => {

  const [qualityRating, setQualityRating] = useState(4)
  const [customerExpRating, setCustomerExpRating] = useState(3)

  const options = () => {

    const optionsArr = []
    for (let i = 0; i < 50; i++) {
      optionsArr[i] = <option value={i+1}>{i + 1}</option>
    }

    return optionsArr
  }
  return (
    <div className={styles.join}>
      <div className={styles.colOne}>
        <header className={styles.header}>
          <Link to="/"> <img src={logo} alt="mainlogix logo" /> </Link>
        </header>
        <div className={styles.colOneContent}>
          <h5>Feel free to drop us a line & give us your feedback</h5>
          <p>
          </p>
        </div>
      </div>
      <div className={styles.colTwo}>
        <div className={styles.mobileContent}>
          <Header />
          <h5>Feel free to drop us a line & give us your feedback</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetuer adipisc
          </p>
        </div>
        <div className={styles.colTwoContent}>
          <div>
            <p>1- How many of our offered products/ services do you currently use?</p>
            <select className={styles.quantity} name="quantity" id="">
              {options()}
            </select>
          </div>
          <div>
            <p>2- Are you happy with our product/ service reliability and performance?</p>
            <div className={styles.radio}>
              <label htmlFor="performanceYes">Yes</label>
              <input type="radio" name="performance" id="performanceYes" />
              <label htmlFor="performanceNo">No</label>
              <input type="radio" name="performance" id="performanceNo" />
            </div>
          </div>
          <div>
            <p>3-  How will you rate our overall quality of packaging?</p>
            <div className={styles.stars}>
              {[1,2,3,4,5].map(num => (
                <>
                  <Star styles={{fill: qualityRating >= num ? "#FE9800" : "#000"}} onClick={() => setQualityRating(num)} />
                </>
              ))}
            </div>
          </div>
          <div>
            <p>4- How will you rate your overall customer experience?</p>
            <div className={styles.stars}>
              {[1,2,3,4,5].map(num => (
                <>
                  <Star styles={{fill: customerExpRating >= num ? "#FE9800" : "#000"}} onClick={() => setCustomerExpRating(num)} />
                </>
              ))}
            </div>
          </div>
          <div>
            <p>5- Would you recommend our products or services to someone?</p>
            <div className={styles.radio}>
              <label htmlFor="recommendationYes">Yes</label>
              <input type="radio" name="recommendation" id="recommendationYes" />
              <label htmlFor="recommendationNo">No</label>
              <input type="radio" name="recommendation" id="recommendationNo" />
            </div>
          </div>
          <div>
            <p>6- Please provide below any additional comments or suggestions?</p>
            <textarea className={styles.textarea} placeholder="Write something..." name="suggestion" id="" cols="30" rows="10"/>
          </div>
          <button className={styles.submit}>SUBMIT</button>
        </div>

      </div>
    </div>
  )
}

export default Feedback
