import React from 'react'
import Hero from '../components/SubCategory/Hero'
import ProductList from '../components/SubCategory/ProductList'
import TopSelling from '../components/SubCategory/RecentlySearched'
import styles from '../sass/pages/SubCategory.module.scss'
import Footer from '../components/Footer'

const SubCategory = () => {
  return (
    <main className={styles.subCategory}>
      <Hero />
      <ProductList />
      <TopSelling />
      <Footer />
    </main>
  )
}

export default SubCategory
