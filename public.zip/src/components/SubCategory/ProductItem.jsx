import React from 'react'
import styles from '../../sass/components/SubCategory/ProductItem.module.scss'
import productItemOne from '../../assets/images/productItemOne.png'
import { Link } from 'react-router-dom'
const ProductItem = ({data}) => {
  return (
    <div className={styles.productItem}>
      <img src={data.img} alt="product item" />
      <div className={styles.productDescription}>
        <div className={styles.text}>
          <h3>{data.title}</h3>
          <p>{data.description} </p>
        </div>
        <div className={styles.new}>NEW</div>
      </div>
      <div className={styles.price}>{data.price}</div>
    </div>
  )
}

export default ProductItem
