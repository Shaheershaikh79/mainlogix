import React from 'react'
import styles from '../../sass/components/SubCategory/ProductList.module.scss'
import ProductItem from './ProductItem'
import productItemOne from '../../assets/images/productItemOne.png'
import productItemTwo from '../../assets/images/productItemTwo.png'
import productItemThree from '../../assets/images/productItemThree.png'

const ProductList = () => {
  return (
    <div className={styles.productList}>
      <div className={styles.filters}>
        <select name="sort" id="">
          <option name="best selling" id="">sort: best selling</option>
          <option name="most viewed" id="">sort: most viewed</option>
          <option name="highly rated" id="">sort: highly rated</option>
        </select>
        <div className={styles.pagination}>
          <span>show rows </span> 
          <select name="rows" id="">
            <option value="10">10</option>
            <option value="15">15</option>
            <option value="20">20</option>
          </select>
          <span> viewing 1-10 of 140</span> 
        </div>
      </div>
      <div className={styles.productItems}>
        <ProductItem data={{
          title: "Medication Intake",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemOne
        }}/>
        <ProductItem data={{
          title: "Remote Health Control",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemTwo
        }}/>
        <ProductItem data={{
          title: "Drug monitoring system",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemThree
        }}/>
        <ProductItem data={{
          title: "Notification System",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemOne
        }}/>
        <ProductItem data={{
          title: "Equipment Tracking",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemTwo
        }}/>
        <ProductItem data={{
          title: "Smart Medical Cabinet",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemThree
        }}/>
        <ProductItem data={{
          title: "Medical Inventory",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemOne
        }}/>
        <ProductItem data={{
          title: "Medication Intake",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemTwo
        }}/>
        <ProductItem data={{
          title: "Equipment Tracking",
          description: "Lorem ipsum dolor sit amet",
          price: "$9.99",
          img: productItemThree
        }}/>
      </div>
    </div>
  )
}

export default ProductList
