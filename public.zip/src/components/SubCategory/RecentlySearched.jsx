import React from 'react'
import SectionHeader from '../SectionHeader'
import styles from '../../sass/components/SubCategory/RecentlySearched.module.scss'
import RecentlySearchedProduct from './RecentlySearchedProduct'

const RecentlySearched = () => {
  return (
    <div className={styles.recentlySearched}>
      <SectionHeader text="Recently Searched Products" />
      <div className={styles.recentlySearchedProducts}>
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
        <RecentlySearchedProduct />
      </div>
    </div>
  )
}

export default RecentlySearched
