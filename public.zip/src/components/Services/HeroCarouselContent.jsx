import React from 'react'
import {Link} from 'react-router-dom'
import styles from '../../sass/components/Services/HeroCarouselContent.module.scss'
const HeroCarouselContent = ({data}) => {
  return (
    <div className={styles.content}>
      <img src={data.illustration} alt="" />
      <header className={styles.header}>
        <h2>{data.industry}</h2>
        <hr />
      </header>
      <p>{data.description}</p>
      <Link to={data.path}>{">"}</Link>
    </div>
  )
}

export default HeroCarouselContent
