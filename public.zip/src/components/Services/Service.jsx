import React from 'react'
import styles from '../../sass/components/Services/Service.module.scss'
import SectionHeader from '../SectionHeader'

const Service = ({service}) => {
  return (
    <div className={styles.service} >
      <div className={styles.serviceImg}>
        <img src={service.img} alt="service" />
      </div>
      <div className={styles.serviceDesc}>
        <SectionHeader text={service.heading} fontSize="1.5rem" />
        <p>{service.summary}</p>
      </div>
    </div>
  )
}

export default Service
