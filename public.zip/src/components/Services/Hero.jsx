import React from 'react'
import styles from '../../sass/components/Home/Hero.module.scss'
import Carousel from '../Carousel'
import Header from '../Header'
import HeroCarouselContent from './HeroCarouselContent'



const Hero = () => {

  return (
    <div className={styles.hero}>
      <Header />
      <iframe width="100%" height="400" src="https://www.youtube.com/embed/LlhmzVL5bm8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>    </div>
  )
}

export default Hero

