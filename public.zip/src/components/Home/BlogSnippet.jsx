import React from 'react'
import { Link } from 'react-router-dom'
import styles from '../../sass/components/Home/BlogSnippet.module.scss'
import SectionHeader from '../SectionHeader'
import smart_home from '../../assets/images/smart_home.jpg'
import user from '../../assets/images/user.png'
import Instagram from '../../assets/icons/Instagram'
import Twitter from '../../assets/icons/Twitter'


const BlogSnippet = () => {
  return (
    <div className={styles.blogSnippet}>
      <SectionHeader text="Snippet of Blog" />
      <div className={styles.blogs}>
        <div className={styles.blog}>
          <div className={styles.blogInfo}>
            <a href="https://dzone.com/articles/the-internet-of-things-in-solutions-architecture">
            <img src={smart_home} alt="smart home" />
            </a>
            <div className={styles.description}>
              <h3>The Internet of Things in Solutions Architecture
</h3>
              <p>Information modeling and event management are critical for detecting changes across complex industrial systems. Industrial IoT solutions can address this.</p>
              <Link to="/">Read More</Link>
            </div>
          </div>
          <hr />
          <div className={styles.authorInfo}>
            <img src={user} alt="blog author" />
            <p><span>By</span><span>Saurabh Shrivastava ·</span></p>
            <p>Apr. 09, 22</p>
          </div>
        </div>
        <div className={styles.blog}>
          <div className={styles.blogInfo}>
            <a href="https://connectedworld.com/cellular-tech-enables-next-gen-transportation/">
            <img src={smart_home} alt="smart home" />
            </a>
            <div className={styles.description}>
              <h3>Cellular Tech Enables Next-Gen Transportation</h3>
              <p>There is no doubt that connected devices and technologies are transforming how humans and machines work together in places like operating rooms, factories, and roadways/intersections</p>
              <Link to="/">Read More</Link>
            </div>
          </div>
          <hr />
          <div className={styles.authorInfo}>
            <img src={user} alt="blog author" />
            <p><span>By</span><span>John Doe</span></p>
            <p>Apr 4 20 20221</p>
          </div>
        </div>
        <div className={styles.blog}>
          <div className={styles.blogInfo}>
            <img src={smart_home} alt="smart home" />
            <div className={styles.description}>
              <h3>Unveiling the Potential Relationship between IoT and Cloud Computing</h3>
              <p>Today, if we look around, we find that IoT, the Internet of Things, disrupts our daily lives, either at home or the workplace. It has been 20 years since this concept has knocked the tech world.</p>
              <Link to="/">Read More</Link>
            </div>
          </div>
          <hr />
          <div className={styles.authorInfo}>
            <a href="https://www.iotforall.com/unveiling-the-potential-relationship-between-iot-and-cloud-computin">
            <img src={user} alt="blog author" />
            </a>
            <p><span>By</span><span>Ritesh Sutaria -
</span></p>
            <p>April 8, 2022</p>
          </div>
        </div>
      </div>
      <div className={styles.newsletter}>
        <div className={styles.brief}>
          <p>Follow us & subscribe our newsletter</p>
          <p>Follow us & stay connected!</p>
        </div>
        <form action="" className={styles.subscribe}>
          <input type="email" placeholder="Enter email..." />
          <button type="submit"> Subscribe </button>
        </form>
        <div className={styles.socials}>
          <a href="https://instagram.com/mainlogixtech?igshid=YmMyMTA2M2Y="><Instagram /></a>
          <a href="https://twitter.com/mainlogixl"><Twitter /></a>
        </div>
      </div>
    </div>
  )
}

export default BlogSnippet
