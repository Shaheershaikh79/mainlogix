import React from 'react'
import styles from '../../sass/components/Home/Hero.module.scss'
import Achievements from './Achievements'
import Carousel from '../Carousel'
import Header from '../Header'
import HeroCarouselContent from './HeroCarouselContent'
import medical from '../../assets/images/medical.jpg'
import medicineSlide from '../../assets/images/medicineSlider.jpg'
import hubTechModule from '../../assets/images/hubTechModule.png'
import homeSlide from '../../assets/images/homeSlider.jpg'



const Hero = () => {
  const slideStyle = {
    display: 'flex',
    alignItems: 'center',
    backgroundColor: 'grey',
    backgroundBlendMode: 'multiply',
  }
  const slides = [{
    imgSrc: hubTechModule,
    content: <HeroCarouselContent title="Hubtecs Technology" description="Hubtecs is an online shop for different electronic and embedded system component." link="http://www.hubtecs.com" />,
    slideStyle
  }, {
    imgSrc: medical,
    content: <HeroCarouselContent  title="Mainlogix Health and Elderly care IOT.
    " description="With our smart Health and Elderly care kit, we provide remote monitoring, prevention of disease, Diet Balancing, Medical Habits like taking of drugs at right time, Walking speed and Temperature measurement for Elderly ones and patients" link="http://www.mainlogix.org" />,
    slideStyle
  }, {
    imgSrc: homeSlide,
    content: <HeroCarouselContent title="Grandeur smart" description="Grandeursmart is a Smart City and Home Automation company, That focuses on Automating securing of homes, City and Community with a wide range of smart devices." link="http://www.grandeursmart.com/" />,
    slideStyle
  }]

  return (
    <div className={styles.hero}>
      <Header />
      <div className={styles.heroCarousel}>
        <Carousel carouselData={slides} controls={{type: "in"}} />
      </div>
      <Achievements />
    </div>
  )
}

export default Hero

