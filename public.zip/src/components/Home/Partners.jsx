import React from 'react'
import SectionHeader from '../SectionHeader'
import styles from '../../sass/components/Home/Partners.module.scss'
import lorawan from '../../assets/images/lorawan.png'
import aws from '../../assets/images/aws.png'
import wave from '../../assets/images/wave.png'

const Partners = () => {
  return (
    <div className={styles.partners}>
      <SectionHeader text="Our Partners" />
      <div className={styles.partnerLogos}>
        <img src={wave} alt="z wave" />
        <img src={aws} alt="aws" />
        <img src={lorawan} alt="lorawan" />
        <img src="/images/matter.png" alt="" />
        <img src="/images/download.png" alt="" />

      </div>
    </div>
  )
}

export default Partners
