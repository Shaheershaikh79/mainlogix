import React from 'react'
import {Link} from 'react-router-dom'
import styles from '../../sass/components/Home/HeroCarouselContent.module.scss'
const HeroCarouselContent = (props) => {
  return (
    <div className={styles.content}>
      <h2>{props.title}</h2>
      <p>
       {props.description}
      </p>
      <a href={props.link}>   SHOP</a>
    </div>
  )
}

export default HeroCarouselContent
