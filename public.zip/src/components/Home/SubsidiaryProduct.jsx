import React from 'react'
import SectionHeader from '../SectionHeader'
import styles from '../../sass/components/Home/SubsidiaryProduct.module.scss'
import { Link } from 'react-router-dom'
import smart_home from '../../assets/images/smart_home.jpg'
import agric from '../../assets/images/agric.jpg'

const SubsidiaryProduct = () => {
  return (
    <div className={styles.subsidiaryProduct}>
      <SectionHeader text="Our Subsidiary Products" />
      <div className={styles.products}>
        <div className={styles.product}>
          <img src={smart_home} alt="smart home" />
          <div className={styles.productInfo}>
            <h3>Smart Home Product</h3>
            <p>Lorem ipsum dolor sit</p>
            <Link to="/">View</Link>
          </div>
        </div>
        <div className={styles.product}>
          <img src={agric} alt="agric" />
          <div className={styles.productInfo}>
            <h3>Agriculture Product</h3>
            <p>Lorem ipsum dolor sit</p>
            <Link to="/">View</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SubsidiaryProduct
