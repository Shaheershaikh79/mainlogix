import React from 'react'
import { Link } from 'react-router-dom'
import styles from '../sass/components/Footer.module.scss'
import logo from '../assets/images/Logo.png'
import appstore from '../assets/images/appstore.png'
import playstore from '../assets/images/playstore.png'
import Facebook from '../assets/icons/Facebook'
import LinkedIn from '../assets/icons/LinkedIn'
import {TwitterTimelineEmbed} from 'react-twitter-embed'

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.logo}>
        <Link to="/">
          <img src={logo} alt="logo" />
        </Link>
      </div>
      <hr />
      <div className={styles.otherLinks}>
        <div className={styles.resources}>
          <h3>RESOURCES</h3>
          <Link to="/login">Sign In</Link>
          <Link to="/signup">Sign Up</Link>
          <Link to="/faq">FAQs</Link>
          <div className={styles.socials}>
            <a href="https://www.facebook.com/Mainlogix-Limited-106534807460511/">
              <Facebook />
            </a>
            <a href="https://www.linkedin.com/company/mainlogix-limited">
              <LinkedIn />
            </a>
          </div>
          <div className={styles.appLinks}>
            <Link to="/">
              <img src={appstore} alt="iOS appstore" />
            </Link>
            <Link to="/">
              <img src={playstore} alt="google playstore" />
            </Link>
          </div>
          <Link to="/">2022 mainlogix.org</Link>
        </div>
        <div className={styles.company}>
          <h3>COMPANY</h3>
          <Link to="/">Home</Link>
          {/* <Link to="/products">Products</Link> */}
          <Link to="/about">About</Link>
          <Link to="/blog">Blog</Link>
          <Link to="/services">Services</Link>
          <Link to="/join">Join Us</Link>
          <Link to="/feedback">Feedback</Link>
        </div>
        <div className={styles.feed}>
          <h3>TWEETS AND INSTA FEED</h3>
          <div className={styles.twitterFeed}>
            <TwitterTimelineEmbed
              sourceType="profile"
              screenName="mainlogixL" // input your twitter handle here
              options={{height: 300}}
            />
          </div>
          <div className={styles.instaFeed}></div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
