import React from 'react'
import styles from '../../sass/components/FAQ/Projects.module.scss'
import SectionHeader from '../SectionHeader'
import projectImg from '../../assets/images/projectImg.jpg'
import { Link } from 'react-router-dom'
import Border from '../../assets/icons/Border'

const Projects = () => {
  return (
    <div className={styles.pastProject}>
      <SectionHeader text="Past Projects" fontSize="1.5rem" />
      <div className={styles.projects}>
        <div className={styles.project}>
          <div className={styles.projectImg}>
            <img src="images/proj1.jpeg" alt="project" />
            <Border className={styles.bottomLeft} />
          </div>
          <div className={styles.projectInfo}>
            <h4>NFC Contact sharing</h4>
            <p>Building of NFC Writer hardware for Programming NFC cards, with different components integrated with the web platform for storing Users Data integrated with analytics.

</p>
          </div>
        </div>
        <div className={styles.project}>
          <div className={styles.projectImg}>
            <img src="/images/proj2.jpeg"  alt="project" />
            <Border className={styles.topRight} />
          </div>
          <div className={styles.projectInfo}>
            <h4>Edge IOT Gateway</h4>
            <p>We have Worked on Edge IOT gateway with multiple protocols like Lora, Bluetooth, Zwave, Zigbee, Wifi etc.

</p>
          </div>
        </div>
        <div className={styles.project}>
          <div className={styles.projectImg}>
            <img src="/images/proj3.jpeg" alt="project" />
            <Border className={styles.topLeft} />
          </div>
          <div className={styles.projectInfo}>
            <h4>Smart Switch and Socket</h4>
          </div>
        </div>
        <div className={styles.project}>
          <div className={styles.projectImg}>
            <img src={projectImg} alt="project" />
            <Border className={styles.bottomRight} />
          </div>
          <div className={styles.projectInfo}>
            <h4>Smart Automatic Changeover</h4>
          </div>
        </div>
      </div>
      <div className={styles.partner}>
        <div className={styles.partnerDesc}>
          <h5>Become a partner</h5>
          <span> Form partner with us and become an accredited agent</span>
        </div>
        <Link to="/join">JOIN</Link>
      </div>
    </div>
  )
}

export default Projects
