import React from 'react'
import SectionHeader from '../SectionHeader'
import styles from '../../sass/components/Products/TopSelling.module.scss'
import TopSellingProduct from './TopSellingProduct'

const TopSelling = () => {
  return (
    <div className={styles.topSelling}>
      <SectionHeader text="Top Selling" />
      <div className={styles.topSellingProducts}>
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
        <TopSellingProduct />
      </div>
    </div>
  )
}

export default TopSelling
