import React from 'react'
import styles from '../../sass/components/Products/TopSellingProduct.module.scss'
import productItemOne from '../../assets/images/productItemOne.png'
import { Link } from 'react-router-dom'

const TopSellingProduct = () => {
  return (
    <div className={styles.product}>
      <img src={productItemOne} alt="product item" />
      <div className={styles.productDescription}>
        <h3>Product Name</h3>
        <p>Lorem ipsum dolor sit</p>
        <p>$9.99</p>
        <Link to="/">BUY NOW</Link>
      </div>
    </div>
  )
}

export default TopSellingProduct
