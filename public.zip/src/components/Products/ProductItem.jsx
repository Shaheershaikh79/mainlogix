import React from 'react'
import styles from '../../sass/components/Products/ProductItem.module.scss'
import productItemOne from '../../assets/images/productItemOne.png'
import { Link } from 'react-router-dom'
const ProductItem = () => {
  return (
    <div className={styles.productItem}>
      <div className={styles.productDescription}>
        <h3>Smart Home Product</h3>
        <p>Lorem ipsum dolor sit </p>
        <Link to="/products/productId">BUY NOW</Link>
      </div>
      <img src={productItemOne} alt="product item" />
    </div>
  )
}

export default ProductItem
