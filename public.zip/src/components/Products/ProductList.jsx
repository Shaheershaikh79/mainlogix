import React from 'react'
import {useNavigate} from 'react-router-dom'
import styles from '../../sass/components/Products/ProductList.module.scss'
import ProductItem from './ProductItem'

const ProductList = () => {

  const navigate = useNavigate()

  const handleSubmit = (e) => {
    e.preventDefault()
    navigate('/category/iot')
  }
  return (
    <div className={styles.productList}>
      <form action="" onSubmit={handleSubmit} className={styles.search}>
        <input type="search" name="search" id="" placeholder="Search..." />
        <select name="ctegories" id="">
          <option value="">Categories</option>
        </select>
      </form>
      <div className={styles.productItems}>
        <ProductItem />
        <ProductItem />
        <ProductItem />
        <ProductItem />
      </div>
    </div>
  )
}

export default ProductList
