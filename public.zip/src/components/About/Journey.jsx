import React from 'react'
import styles from '../../sass/components/About/Journey.module.scss'
import SectionHeader from '../SectionHeader'
import company from '../../assets/images/company.jpg'
import growth from '../../assets/images/growth.jpg'

const Journey = () => {
  return (
    <div className={styles.journey}>
      <SectionHeader text="Our Journey" fontSize="1.5rem" />
      <div className={styles.journeyContent}>
        <div className={styles.companyDetail}>
          <h3>Company’s detail</h3>
          <p>
          Mainlogix Technology Limited is an Internet of Things company in Lagos, Nigeria that designs its system to majorly solve the challenges which are experienced both indoors and outdoors using automation and automated systems Technology. Automation comprises a wide range of solutions for monitoring, controlling, securing, managing, and automating functions and scenarios. It can also be used to monitor connected hardware or devices. Mainlogix Limited has other subsidiaries that focus on different sectors of Technology,Subsidiaries like Intelkard and GrandeurSmart.
          </p>
          <img src={company} alt="office" />
        </div>
        <div className={styles.historyAndGrowth}>
          <img src={growth} alt="plant in vase" />
          <div>
            <h3>History and Growth</h3>
            <p>
            GrandeurSmart by Mainlogix is an Home Automation company that focuses on designing, Manufacturing smart devices for Homes and Ofﬁces and provides Smart solutions to Controlling, Automating Home devices from Mobile phones. It is founded in the year 2019.<br/><br/>

Intelkard by Mainlogix is a company that focuses on using NFC technology to share business or Contact Information with just a tap of the Card on Mobile Devices. Intelkard focuses on Designing and manufacturing smart Modern-day Business cards to replace the traditional method of Contact Information sharing. It is founded in the year 2021            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Journey
