import React from 'react'
import styles from '../../sass/components/About/Teams.module.scss'
import SectionHeader from '../SectionHeader'
import avatar from '../../assets/images/avatar.png'

const Teams = () => {
  return (
    <div className={styles.teams}>
      <SectionHeader text="Core Team" fontSize="1.5rem" />
      <div className={styles.members}>
        <div className={styles.member}>
          <div className={styles.memberImg}>
            <img src={avatar} alt="avatar" />
          </div>
          <div className={styles.memberInfo}>
            <h4>Lorem ipsum</h4>
            <span>Lorem ipsum</span>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad</p>
          </div>
        </div>
        <div className={styles.member}>
          <div className={styles.memberImg}>
            <img src={avatar} alt="avatar" />
          </div>
          <div className={styles.memberInfo}>
            <h4>Lorem ipsum</h4>
            <span>Lorem ipsum</span>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad</p>
          </div>
        </div>
        <div className={styles.member}>
          <div className={styles.memberImg}>
            <img src={avatar} alt="avatar" />
          </div>
          <div className={styles.memberInfo}>
            <h4>Lorem ipsum</h4>
            <span>Lorem ipsum</span>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad</p>
          </div>
        </div>
        <div className={styles.member}>
          <div className={styles.memberImg}>
            <img src={avatar} alt="avatar" />
          </div>
          <div className={styles.memberInfo}>
            <h4>Lorem ipsum</h4>
            <span>Lorem ipsum</span>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Teams
