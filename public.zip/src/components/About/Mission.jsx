import React from 'react'
import styles from '../../sass/components/About/Mission.module.scss'
import SectionHeader from '../SectionHeader'
import visionOne from '../../assets/images/visionOne.jpg'
import visionTwo from '../../assets/images/visionTwo.jpg'

const Mission = () => {
  return (
    <div className={styles.mission}>
      <SectionHeader text="Our Mission & Vision" fontSize="1.5rem" />
      <div className={styles.missionContent}>
        <div className={styles.description}>
          <p>
          MainLogix Technologies is positioning itself to be the top company in Africa in Internet of Things technology development and delivery.
            <br />
            <br />
            The goal is to equip every available home, City, Community with smart technology and integrate retroﬁtted smart system, security systems and other automated devices to make the regular system connected, modern and smart.
Also to Advance and use technology to solve human challenges.
<br />
<br />
MainLogix visualise a world where all things and way of living becomes more efﬁcient, safer, secure, energy efﬁcient, improve the quality of life and more entertaining to live in.
       
       
<br />
<br />
We have the ﬁrm believe that this ideal can be achieved in the next 5 years


          </p>
        </div>
        <div className={styles.images}>
          <img src={visionTwo} alt="vision" />
          <img src={visionOne} alt="vision" />
        </div>
      </div>
    </div>
  )
}

export default Mission
